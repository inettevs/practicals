#ifndef SINGLY_SinglyList_CPP
#define SINGLY_SinglyList_CPP
#include "SinglyLinked.h"

template<class T>
SinglyList<T>::SinglyList() : List<T>() { }

template<class T>
SinglyList<T>::SinglyList(T* arr, int size) : List<T>() {
    if (arr == NULL || size <= 0) {
        return; // Invalid array or size, leave the list empty
    }

    // Populate the linked list with values from the array
    for (int i = 0; i < size; ++i) {
        insert(arr[i], i);
    }
}

template<class T>
SinglyList<T>::~SinglyList() {
    // Destroy any remaining nodes in the list and deallocate memory
    Node<T>* current = this->head;
    Node<T>* next;

    while (current != NULL) {
        next = current->next;
        delete current;
        current = next;
    }

    this->head = NULL;
}

template<class T>
Node<T>* SinglyList<T>::insert(T data, int pos) {
    Node<T>* newNode = new Node<T>(data);
    Node<T>* current = this->head;
    Node<T>* prev = NULL;
    newNode->next = NULL;

    if (!this->head){
         // Insert at the beginning
        current = this->head;
        newNode->next = this->head;
        this->head = newNode;
        return newNode;

    }
    if (pos <= 0) {
        // Insert at the beginning
        current = this->head;
        newNode->next = this->head;
        this->head = newNode;
    } else if ( pos > this->size()) {
        // Traverse to the position or the end if pos > number of nodes
        current = this->head;

        while (current->next != NULL) {
            current = current->next;
        }

        // Insert the node at the correct position
        current->next = newNode;
    } else {
        for (int i = 0; i < pos; i++)
        {
            prev = current;
            current = current->next;
        }

        if (prev == NULL){
            this->head = newNode;
            newNode->next = newNode;
        }else{
        prev->next = newNode;
        newNode->next = current;
    }
    }
    return newNode;
}


template<class T>
int SinglyList<T>::remove(T data) {
    Node<T>* current = this->head;
    Node<T>* prev = NULL;
    int index = 0;

    while (current != NULL && current->getData() != data) {
        prev = current;
        current = current->next;
        index++;
    }

    if (current == NULL) {
        // Data not found
        return -1;
    }

    if (prev == NULL) {
        // Data found at the head
        this->head = current->next;
    } else {
        // Data found in the middle or end
        prev->next = current->next;
    }

    delete current;
    return index;
}

template<class T>
int SinglyList<T>::getIndexFromFront(T data) const {
    Node<T>* current = this->head;
    int index = 0;

    while (current != NULL) {
        if (current->getData() == data) {
            return index; // Data found, return index
        }
        current = current->next;
        index++;
    }

    return -1; // Data not found
}

template<class T>
int SinglyList<T>::getIndexFromRear(T data) const {
    Node<T>* current = this->head;
    int index = -1, currentIndex = 0;

    while (current != NULL) {
        if (current->getData() == data) {
            index = currentIndex; // Data found, update index
        }
        current = current->next;
        currentIndex++;
    }

    return index;
}

template<class T>
List<T>* SinglyList<T>::sort(bool order) const {
    SinglyList<T>* sortedList = new SinglyList<T>();
    Node<T>* current = this->head;

    while (current != NULL) {
        sortedList->insert(current->getData(), sortedList->getIndexFromFront(current->getData()));
        current = current->next;
    }

    return sortedList;
}

template<class T>
Node<T>* SinglyList<T>::operator[](int index) const {
    if (this->head == NULL) {
        return NULL; // Empty list
    }

    Node<T>* current = this->head;

    if (index >= 0) {
        // Forward indexing
        for (int i = 0; i < index && current != NULL; ++i) {
            current = current->next;
        }
    } else {
        // Backward indexing
        int size = 0;
        Node<T>* temp = this->head;
        while (temp != NULL) {
            temp = temp->next;
            size++;
        }

        index = size + index; // Convert negative index to positive
        if (index < 0 || index >= size) {
            return NULL; // Out of bounds
        }

        for (int i = 0; i < index && current != NULL; ++i) {
            current = current->next;
        }
    }

    return current;
}

template<class T>
Node<T>* SinglyList<T>::operator()(T* dataPtr) const {
    if (dataPtr == NULL || this->head == NULL) {
        return NULL; // Invalid data pointer or empty list
    }

    Node<T>* current = this->head;

    while (current != NULL) {
        if (current->getData() == *dataPtr) {
            return current; // Data found
        }
        current = current->next;
    }

    return NULL; // Data not found
}

template<class T>
Node<T>* SinglyList<T>::findSmallest() const {
    if (this->head == NULL) {
        return NULL; // Empty list
    }

    Node<T>* current = this->head;
    Node<T>* smallest = current;

    while (current != NULL) {
        if (current->getData() < smallest->getData()) {
            smallest = current; // Update smallest node
        }
        current = current->next;
    }

    return smallest;
}


template<class T>
Node<T>* SinglyList<T>::findBiggest() const {
    if (this->head == NULL) {
        return NULL; // Empty list
    }

    Node<T>* current = this->head;
    Node<T>* biggest = current;

    while (current != NULL) {
        if (current->getData() > biggest->getData()) {
            biggest = current; // Update biggest node
        }
        current = current->next;
    }

    return biggest;
}

template<class T>
List<T>* SinglyList<T>::clone() const {
    SinglyList<T>* clonedList = new SinglyList<T>();
    Node<T>* current = this->head;

    while (current != NULL) {
        clonedList->insert(current->getData(), clonedList->getIndexFromFront(current->getData()));
        current = current->next;
    }

    return clonedList;
}


template <class T>
std::ostream &operator<<(std::ostream &os, const SinglyList<T> *sl)
{
    if (sl->head == NULL)
    {
        os << "NULL";
        return os;
    }
    Node<T> *curr = sl->head;
    while (curr != NULL)
    {
        os << curr;
        curr = curr->next;
    }
    return os;
}

#endif /*SinglyList_CPP*/

