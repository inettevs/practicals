#include "List.h"
#include "Node.h"
#include "SinglyLinked.h"

#include <iostream>
#include <string>

using namespace std;

int main(int argc, char const *argv[])
{
    Node<int>* node1 = new Node<int>(42);
    Node<int>* node2 = new Node<int>(20);
    Node<int>* node3 = new Node<int>(42);
    std::cout << "Node 1 data: " << node1->getData() << std::endl;
    std::cout << "Node 2 data: " << node2->getData() << std::endl;
    std::cout << "Node 3 data: " << node3->getData() << std::endl;

    // Testing equality operator
    if (*node1 == node2->getData()) {
        std::cout << "Node 1 is equal to Node 2." << std::endl;
    } else {
        std::cout << "Node 1 is not equal to Node 2." << std::endl;
    }

    if (*node1 == node3->getData()) {
        std::cout << "Node 1 is equal to Node 3." << std::endl;
    } else {
        std::cout << "Node 1 is not equal to Node 3." << std::endl;
    }

     // Testing the ostream operator
    std::cout << "Node 1: " << node1 << std::endl;
    std::cout << "Node 2: " << node2 << std::endl;
    std::cout << "Node 3: " << node3 << std::endl;

    // Cleanup
    delete node1;
    delete node2;
    delete node3;

     // Testing SinglyList
    int arr[] = {5, 2, 8, 1, 6};
    int arrSize = sizeof(arr) / sizeof(arr[0]);

    SinglyList<int>* myList = new SinglyList<int>(arr, arrSize);
    std::cout << "Original List: " << myList << std::endl;

     // Testing insert
    myList->insert(4, 2);
    std::cout << "List after inserting 4 at position 2: " << myList << std::endl;

    // Testing remove
    int removedIndex = myList->remove(8);
    std::cout << "List after removing element 8 (index: " << removedIndex << "): " << myList << std::endl;

    // Testing getIndexFromFront
    int indexFromFront = myList->getIndexFromFront(6);
    std::cout << "Index of element 6 from the front: " << indexFromFront << std::endl;

    // Testing getIndexFromRear
    int indexFromRear = myList->getIndexFromRear(6);
    std::cout << "Index of element 6 from the rear: " << indexFromRear << std::endl;

    // Testing sort
    SinglyList<int>* sortedList = dynamic_cast<SinglyList<int>*>(myList->sort(true));
    std::cout << "Sorted List (ascending order): " << sortedList << std::endl;

    // Testing findSmallest
    Node<int>* smallestNode = myList->findSmallest();
    std::cout << "Smallest element: " << smallestNode->getData() << std::endl;

    // Testing findBiggest
    Node<int>* biggestNode = myList->findBiggest();
    std::cout << "Biggest element: " << biggestNode->getData() << std::endl;

    // Testing clone
    SinglyList<int>* clonedList = dynamic_cast<SinglyList<int>*>(myList->clone());
    std::cout << "Cloned List: " << clonedList << std::endl;

    // Cleanup
    delete myList;
    delete sortedList;
    delete clonedList;
    return 0;
}