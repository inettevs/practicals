#include <iostream>
#include <sstream> 
#include "node.h"

// Note that all functions can be called on ANY node in the list. A list refers to all nodes that are connected to the current node in both directions 

node::node(int val) 
{ 
    data=val;
    prev=NULL; 
    next=NULL; 
}

node::~node() 
{
    prev=NULL;
    next=NULL;
}


void node::destroyList()
{ 
node* current = tail(); 
    
    while (current != NULL) {
        node* prevNode = current->prev; 
        delete current;
        current = prevNode;

    }
}

bool node::contains(int val)
{ 
   node* current = head();

    while (current != NULL) {
        if (current->data == val) {
            return true; 
        }
        current = current->next;
    }

    return false;
}


void node::insert(int val) 
{
    if (contains(val)) {
        return; 
    }

    node* newNode = new node(val);

    node* current = this->head();
    while (current->next != NULL && current->next->data < val) {
        current = current->next;
    }

    newNode->next = current->next;
    if (current->next != NULL) {
        current->next->prev = newNode;
    }
    current->next = newNode;
    newNode->prev = current;
}


void node::insert(node* n) 
{ 
    // Traverse the current list
    node* trav1 = this->head();
    // Traverse the passed-in list
    node* trav2 = n->head();

    // Traverse both lists and insert elements in ascending order
    while (trav1 != NULL && trav2 != NULL) {
        if (trav1->data <= trav2->data) {
            // Move to the next node in the current list
            trav1 = trav1->next;
        } else {
            // Insert the node from the passed-in list into the current list
            node* newNode = new node(trav2->data);

            // Update pointers to insert the new node
            newNode->next = trav1;
            newNode->prev = trav1->prev;

            if (trav1->prev != NULL) {
                trav1->prev->next = newNode;
            } else {
                // Update head if inserting at the beginning
                this->data = newNode->data;
                this->next = newNode->next;
                this->prev = newNode->prev;
            }

            trav1->prev = newNode;

            // Move to the next node in the passed-in list
            trav2 = trav2->next;
        }
    }

    // If there are remaining nodes in the passed-in list, append them to the current list
    while (trav2 != NULL) {
        insert(trav2->data);
        trav2 = trav2->next;
    }
}


void node::print()
{
   node* current = this->head();

    if (current == this) {
        std::cout << "[" << current->data << "]";
    } else {
        std::cout << current->data;
    }
    current = current->next;

    while (current != NULL) {
        std::cout << "->";
        if (current == this) {
            std::cout << "[" << current->data << "]";
        } else {
            std::cout << current->data;
        }

        current = current->next;
    }
    std::cout << std::endl;
}


node* node::remove(int val)
{ 
    node* current = head();

    while (current != NULL && current->data != val) {
        current = current->next;
    }

    if (current == NULL) {
        return NULL; 
    }

    if (current->prev != NULL) {
        current->prev->next = current->next;
    }

    if (current->next != NULL) {
        current->next->prev = current->prev;
    }

    current->prev = NULL;
    current->next = NULL;

    return current;
}

node* node::head()
{ 
 node* current = this;
    while (current->prev != NULL) {
        current = current->prev;
    }
    return current;
}

node* node::tail()
{ 
    node* current = this;
    while (current->next != NULL) {
        current = current->next;
    }
    return current;
}

int node::length()
{ 
    int count = 0;
    node* current = head();  
    while (current != NULL) {
    count++;
    current = current->next;
    }
    return count;
}
